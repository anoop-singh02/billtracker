<?php
session_start();
require_once '../config/database.php';
require_once '../includes/auth.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$data = json_decode(file_get_contents('php://input'), true);
$billId = $data['billId'] ?? null;

if (!$billId) {
    echo json_encode(['success' => false, 'message' => 'Bill ID is required']);
    exit();
}

// Check if user has access to this bill
$stmt = $conn->prepare("
    SELECT status, user_id 
    FROM bills 
    WHERE id = ?
");
$stmt->bind_param("i", $billId);
$stmt->execute();
$result = $stmt->get_result();
$bill = $result->fetch_assoc();

if (!$bill || (!isAdmin() && $bill['user_id'] !== $_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

// Toggle status
$newStatus = $bill['status'] === 'paid' ? 'unpaid' : 'paid';
$stmt = $conn->prepare("UPDATE bills SET status = ? WHERE id = ?");
$stmt->bind_param("si", $newStatus, $billId);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'status' => $newStatus]);
} else {
    echo json_encode(['success' => false, 'message' => 'Database error']);
}