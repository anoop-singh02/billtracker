// AJAX functions for bill management
function toggleBillStatus(billId) {
    fetch('api/toggle_bill_status.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ billId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Update UI without page reload
            const billElement = document.querySelector(`[data-bill-id="${billId}"]`);
            const statusBadge = billElement.querySelector('.status-badge');
            const newStatus = data.status;
            
            statusBadge.textContent = newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
            statusBadge.className = `status-badge ${newStatus === 'paid' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}`;
        }
    })
    .catch(error => console.error('Error:', error));
}

// Form validation
function validateBillForm(form) {
    const title = form.querySelector('[name="title"]').value;
    const amount = parseFloat(form.querySelector('[name="amount"]').value);
    const dueDate = form.querySelector('[name="due_date"]').value;
    const category = form.querySelector('[name="category"]').value;
    
    if (!title || title.trim() === '') {
        alert('Please enter a bill title');
        return false;
    }
    
    if (isNaN(amount) || amount <= 0) {
        alert('Please enter a valid amount');
        return false;
    }
    
    if (!dueDate) {
        alert('Please select a due date');
        return false;
    }
    
    if (!category) {
        alert('Please select a category');
        return false;
    }
    
    return true;
}

// Initialize date inputs
document.addEventListener('DOMContentLoaded', function() {
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        if (!input.value) {
            input.valueAsDate = new Date();
        }
    });
});