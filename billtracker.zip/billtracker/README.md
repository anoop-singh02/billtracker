## Bill Tracker Application

### Requirements
- XAMPP 8.0 or higher
- PHP 8.0 or higher
- MySQL 5.7 or higher
- Modern web browser

### Installation
1. Copy all files to your XAMPP htdocs folder (e.g., `C:/xampp/htdocs/billtracker/`)
2. Import `database.sql` into phpMyAdmin to create the database and tables
3. Update database credentials in `config/database.php` if needed
4. Access the application at `http://localhost/billtracker`

### Default Login Credentials
- Admin: username: admin, password: admin123
- User: username: user, password: user123

### Features
- User authentication and authorization
- Bill management (CRUD operations)
- Dashboard with statistics
- Admin panel for user management
- AJAX for dynamic updates
- Responsive design

### External Resources
- Bootstrap 5.3.0 (CSS Framework)
- Lucide Icons (Icon Library)
- Chart.js (Charts)