<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BillTracker - Manage Your Bills Efficiently</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-gray-50">
    <?php
    session_start();
    require_once 'config/database.php';
    require_once 'includes/auth.php';
    
    // Router
    $page = isset($_GET['page']) ? $_GET['page'] : 'home';
    $allowedPages = ['home', 'login', 'register', 'dashboard', 'bills', 'admin'];
    
    if (!in_array($page, $allowedPages)) {
        $page = 'home';
    }
    
    // Auth check for protected pages
    if (in_array($page, ['dashboard', 'bills', 'admin']) && !isLoggedIn()) {
        header('Location: index.php?page=login');
        exit();
    }
    
    // Admin check
    if ($page === 'admin' && !isAdmin()) {
        header('Location: index.php?page=dashboard');
        exit();
    }
    
    include "pages/$page.php";
    ?>
    
    <script>
        // Initialize Lucide icons
        lucide.createIcons();
    </script>
    <script src="js/main.js"></script>
</body>
</html>